/*
    Purpose:    Database creation script.
    Author:     J. Berendt
    Date:       2025-03-18
    Revision:   1

    Updates:
    1:  Written.
*/

CREATE DATABASE IF NOT EXISTS `security_logs`;

